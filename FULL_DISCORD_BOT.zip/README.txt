FULL DISCORD BOT

Features:
- Ticket system
- Close button
- Application form
- Accept/Reject system
- Role system
- Log system

Setup:
1. npm install
2. fill .env
3. node index.js
