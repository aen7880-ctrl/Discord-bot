
require("dotenv").config();
const {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  Events
} = require("discord.js");

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]
});

// ===== SETTINGS =====
const YETKILI_ROL = "ROL_ID";
const LOG_KANAL = "LOG_KANAL_ID";
const BASVURU_KANAL = "BASVURU_KANAL_ID";
const VERILECEK_ROL = "VERILECEK_ROL_ID";
const OWNER_ID = "DISCORD_ID";

// ===== READY =====
client.once("ready", () => {
  console.log("Bot aktif: " + client.user.tag);
});

// ===== SIMPLE PANEL =====
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  if (message.content === "!panel") {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("ticket")
        .setLabel("🎫 Ticket Aç")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("form")
        .setLabel("📝 Başvuru")
        .setStyle(ButtonStyle.Success)
    );

    message.channel.send({ content: "Panel:", components: [row] });
  }

  if (message.author.id === OWNER_ID) {
    if (message.content === "!status") message.reply("🟢 Bot çalışıyor");
    if (message.content === "!ping") message.reply("🏓 Pong");
  }
});

// ===== INTERACTIONS =====
client.on("interactionCreate", async (interaction) => {

  // TICKET
  if (interaction.isButton() && interaction.customId === "ticket") {
    const channel = await interaction.guild.channels.create({
      name: `ticket-${interaction.user.username}`,
      permissionOverwrites: [
        { id: interaction.guild.id, deny: ["ViewChannel"] },
        { id: interaction.user.id, allow: ["ViewChannel", "SendMessages"] },
        { id: YETKILI_ROL, allow: ["ViewChannel", "SendMessages"] }
      ]
    });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("close")
        .setLabel("❌ Kapat")
        .setStyle(ButtonStyle.Danger)
    );

    channel.send({ content: "Ticket açıldı", components: [row] });
    interaction.reply({ content: "Ticket açıldı!", ephemeral: true });
  }

  // CLOSE TICKET
  if (interaction.isButton() && interaction.customId === "close") {
    if (!interaction.member.roles.cache.has(YETKILI_ROL)) {
      return interaction.reply({ content: "Yetkin yok", ephemeral: true });
    }

    const log = interaction.guild.channels.cache.get(LOG_KANAL);
    if (log) log.send(`📛 Ticket kapatıldı: ${interaction.channel.name}`);

    interaction.reply({ content: "Kapanıyor...", ephemeral: true });

    setTimeout(() => interaction.channel.delete().catch(() => {}), 3000);
  }

  // FORM OPEN
  if (interaction.isButton() && interaction.customId === "form") {
    const modal = new ModalBuilder()
      .setCustomId("apply")
      .setTitle("Başvuru");

    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId("isim").setLabel("İsim").setStyle(TextInputStyle.Short)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId("yas").setLabel("Yaş").setStyle(TextInputStyle.Short)
      )
    );

    await interaction.showModal(modal);
  }

  // FORM SUBMIT
  if (interaction.isModalSubmit() && interaction.customId === "apply") {
    const kanal = interaction.guild.channels.cache.get(BASVURU_KANAL);

    const embed = new EmbedBuilder()
      .setTitle("Yeni Başvuru")
      .addFields(
        { name: "Kullanıcı", value: `<@${interaction.user.id}>` },
        { name: "İsim", value: interaction.fields.getTextInputValue("isim") },
        { name: "Yaş", value: interaction.fields.getTextInputValue("yas") }
      );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`onay_${interaction.user.id}`).setLabel("✅").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`red_${interaction.user.id}`).setLabel("❌").setStyle(ButtonStyle.Danger)
    );

    kanal.send({ embeds: [embed], components: [row] });

    interaction.reply({ content: "Gönderildi", ephemeral: true });
  }

  // ONAY RED
  if (interaction.isButton()) {
    if (!interaction.member.roles.cache.has(YETKILI_ROL)) return;

    const log = interaction.guild.channels.cache.get(LOG_KANAL);

    if (interaction.customId.startsWith("onay_")) {
      const id = interaction.customId.split("_")[1];
      const member = await interaction.guild.members.fetch(id);
      await member.roles.add(VERILECEK_ROL);

      interaction.update({ content: "✅ Onaylandı", components: [] });
      if (log) log.send(`✅ Onaylandı: <@${id}>`);
    }

    if (interaction.customId.startsWith("red_")) {
      const id = interaction.customId.split("_")[1];
      interaction.update({ content: "❌ Reddedildi", components: [] });
      if (log) log.send(`❌ Reddedildi: <@${id}>`);
    }
  }
});

client.login(process.env.TOKEN);
